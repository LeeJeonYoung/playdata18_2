package com.service.cart;

import com.dto.goods.CartDTO;

public interface CartService {

	public int cartAdd(CartDTO dto) throws Exception;
}
