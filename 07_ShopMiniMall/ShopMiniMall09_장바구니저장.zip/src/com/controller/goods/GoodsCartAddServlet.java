package com.controller.goods;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.goods.CartDTO;
import com.dto.goods.GoodsDTO;
import com.dto.member.MemberDTO;
import com.service.cart.CartService;
import com.service.cart.CartServiceImpl;
import com.service.goods.GoodsService;
import com.service.goods.GoodsServiceImpl;

/**
 * Servlet implementation class GoodsListServlet
 */
@WebServlet("/GoodsCartAddServlet")
public class GoodsCartAddServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gImage=dress1&gCode=D1&gName=인디안+무드+엔틱+니들+드레스&gPrice=37800&goods_size=L&goods_color=navy&goods_amount=1
		
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String next ="";
		if(dto != null) {
			
			String gImage = request.getParameter("gImage");
			String gCode = request.getParameter("gCode");
			String gName = request.getParameter("gName");
			String gPrice = request.getParameter("gPrice");
			String goods_size = request.getParameter("goods_size");
			String goods_color = request.getParameter("goods_color");
			String goods_amount = request.getParameter("goods_amount");
			CartDTO cartDTO = new CartDTO();
			cartDTO.setgImage(gImage);
			cartDTO.setgCode(gCode);
			cartDTO.setgName(gName);
			cartDTO.setgPrice(Integer.parseInt(gPrice));
			cartDTO.setgSize(goods_size);
			cartDTO.setgColor(goods_color);
			cartDTO.setgAmount(Integer.parseInt(goods_amount));
			cartDTO.setUserid(dto.getUserid());
			
			//service
			CartService service = new CartServiceImpl();
			try {
				int num = service.cartAdd(cartDTO);
				next = "goods/cartAddSuccess.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				next = "error/error.jsp";
			}
			
		}else {
			next = "member/sessionInvalidate.jsp";
		}
		// forward 하면 url이 변경안됨.GoodsCartAddServlet로 남아있기
		//때문에 새로고침시 cart에 다시 추가할려고 하기 때문에
		response.sendRedirect(next); 
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
