package com.controller.goods;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.goods.CartDTO;
import com.dto.goods.GoodsDTO;
import com.dto.member.MemberDTO;
import com.service.cart.CartService;
import com.service.cart.CartServiceImpl;
import com.service.goods.GoodsService;
import com.service.goods.GoodsServiceImpl;
import com.service.member.MemberService;
import com.service.member.MemberServiceImpl;

/**
 * Servlet implementation class GoodsListServlet
 */
@WebServlet("/GoodsOrderConfirmServlet")
public class GoodsOrderConfirmServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		// num 이용해서 car테이블의 정보를 가져온다.
		String num = request.getParameter("num");
		System.out.println(num);
		//  세션에 저장된 값(userid)을 이용해서 member테이블의 정보를 가져온다.
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		
		String next ="";
		if(dto != null) {
			
			try {
				//상품정보
				CartService cartService = new CartServiceImpl();
				CartDTO cartDTO = cartService.cartByNum(Integer.parseInt(num));

				//고객정보
				String userid = dto.getUserid();
				MemberService memberService = new MemberServiceImpl();
				MemberDTO memberDTO = memberService.mypage(userid);
				
				request.setAttribute("cDTO", cartDTO);
				request.setAttribute("mDTO", memberDTO);
				next ="orderConfirm.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				next ="error/error.jsp";
			}
			
		}else {
			next = "member/sessionInvalidate.jsp";
		}
		request.getRequestDispatcher(next).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
