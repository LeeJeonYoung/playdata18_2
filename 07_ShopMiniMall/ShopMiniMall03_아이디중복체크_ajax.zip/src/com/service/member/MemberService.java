package com.service.member;

import org.apache.ibatis.session.SqlSession;

import com.dto.member.MemberDTO;

public interface MemberService {

	public MemberDTO idDuplicateCheck(String userid)throws Exception;
}
