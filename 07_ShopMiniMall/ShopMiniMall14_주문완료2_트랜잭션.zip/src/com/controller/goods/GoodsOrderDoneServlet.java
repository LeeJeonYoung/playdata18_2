package com.controller.goods;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.goods.CartDTO;
import com.dto.goods.GoodsDTO;
import com.dto.goods.OrderDTO;
import com.dto.member.MemberDTO;
import com.service.cart.CartService;
import com.service.cart.CartServiceImpl;
import com.service.goods.GoodsService;
import com.service.goods.GoodsServiceImpl;
import com.service.member.MemberService;
import com.service.member.MemberServiceImpl;

/**
 * Servlet implementation class GoodsListServlet
 */
@WebServlet("/GoodsOrderDoneServlet")
public class GoodsOrderDoneServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*  ?gCode=B2&
		 *   gName=레이스+프린지+스커트&
		 *   gPrice=9800&
		 *   gSize=L&
		 *   gColor=navy&
		 *   gAmount=1&
		 *   gImage=bottom2&
		 *   orderName=aaa&
		 *   post1=63043&
		 *   addr1=제주특별자치도+제주시+애월읍+애월남길+5&
		 *   addr2=제주특별자치도+제주시+애월읍+애월리+1486-1&
		 *   phone=011-1234-5678&
		 *   payMethod=신용카드
		 */
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		
		String next ="";
		if(dto != null) {
			try {
				//주문자 정보(로그인 정보)
				String userid = dto.getUserid();
				//상품정보
				String gCode = request.getParameter("gCode");
				String gName = request.getParameter("gName");
				String gPrice = request.getParameter("gPrice");
				String gSize = request.getParameter("gSize");
				String gColor = request.getParameter("gColor");
				String gAmount = request.getParameter("gAmount");
				String gImage = request.getParameter("gImage");
				//배송정보
				String orderName = request.getParameter("orderName");
				String post1 = request.getParameter("post1");
				String addr1 = request.getParameter("addr1");
				String addr2 = request.getParameter("addr2");
				String phone = request.getParameter("phone");
				//결제정보
				String payMethod = request.getParameter("payMethod");
				
				//cart에서 삭제할 num
				String cartNum = request.getParameter("cartNum");
				
				
				OrderDTO orderDTO = new OrderDTO();
				orderDTO.setUserid(userid);
				orderDTO.setgCode(gCode);
				orderDTO.setgName(gName);
				orderDTO.setgPrice(Integer.parseInt(gPrice));
				orderDTO.setgSize(gSize);
				orderDTO.setgColor(gColor);
				orderDTO.setgAmount(Integer.parseInt(gAmount));
				orderDTO.setgImage(gImage);
				orderDTO.setOrderName(orderName);
				orderDTO.setPost(post1);
				orderDTO.setAddr1(addr1);
				orderDTO.setAddr2(addr2);
				orderDTO.setPhone(phone);
				orderDTO.setPayMethod(payMethod);
						
				
				CartService service = new CartServiceImpl();
				int n = service.orderDone(orderDTO, cartNum);
				
				request.setAttribute("orderDTO", orderDTO);
				next ="orderDone.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				next ="error/error.jsp";
			}
			
		}else {
			next = "member/sessionInvalidate.jsp";
		}
		request.getRequestDispatcher(next).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
