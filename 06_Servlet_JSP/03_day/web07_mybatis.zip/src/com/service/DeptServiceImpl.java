package com.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.dao.DeptDAO;
import com.dto.DeptDTO;

public class DeptServiceImpl implements DeptService {

	/*   정형화된 코드
	 *    public void method(){
	 *    SqlSession session = MySqlSessionFactory.getSession();
	 *      try{
	 *    
	 *    
	 *      }finally{
	 *        session.close();
	 *      }
	 *    }
	 * 
	 * 
	 */
	
	@Override
	public List<DeptDTO> selectAll() {
		List<DeptDTO> list= null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			list = dao.selectAll(session);
		}finally {
			session.close();
		}
		return list;
	}

	@Override
	public DeptDTO selectByDeptno(int deptno) {
		DeptDTO dto = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			dto = dao.selectByDeptno(session, deptno);
		}finally {
			session.close();
		}
		return dto;
	}
	@Override
	public int insert(DeptDTO dto) {
		int num=0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			num = dao.insert(session, dto);
			session.commit();
		}finally {
			session.close();
		}
		return num;
	}
	@Override
	public List<DeptDTO> selectByDname(String dname) {
		List<DeptDTO> list= null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			list = dao.selectByDname(session, dname);
		}finally {
			session.close();
		}
		return list;
	}

	@Override
	public List<DeptDTO> selectByDnameLoc(HashMap<String, String> map) {
		List<DeptDTO> list= null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			list = dao.selectByDnameLoc(session, map);
		}finally {
			session.close();
		}
		return list;
	}



	@Override
	public int update(DeptDTO dto) {
		int num=0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			num = dao.update(session, dto);
			session.commit();
		}finally {
			session.close();
		}
		return num;
	}

	@Override
	public int delete(int deptno) {
		int num=0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			num = dao.delete(session, deptno);
			session.commit();
		}finally {
			session.close();
		}
		return num;
	}

}
