package com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


public class EncodingFilter implements Filter {


	public void destroy() {
		System.out.println("EncodingFilter.destory");
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("EncodingFilter.doFilter");
		
		//요청필터 작업영역시작
		//1.한글처리
		System.out.println("요청필터");
		request.setCharacterEncoding("utf-8");
		//2.시작
		long req_time = System.currentTimeMillis();
		//요청필터 작업영역 끝
		chain.doFilter(request, response);
		//응답필터 작업영역시작
		System.out.println("응답필터");
		long res_time = System.currentTimeMillis();
		//응답필터 작업영역 끝
		
		System.out.println("처리시간:"+(res_time-req_time));
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("EncodingFilter.init");
	}

}
