package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		//DB연동 유효성 체크할것.
		boolean result = true;
		String mesg = "";
		if(result) {
			
			//세션얻기
			// request.getSession(): 세션이 있으면 반환하고 세션이 없으면 생성후 반환한다.
			HttpSession session = request.getSession();
			//데이터 저장
			session.setAttribute("m1", userid);

			mesg += "안녕하세요"+userid+"님";
			mesg += "<h2>로그인성공</h2>";
			mesg +=" <a href='MemberInfoServlet'>회원정보보기</a>";
		}else {
			//userid 또는 passwd 틀림
			//다시 로그인 또는 회원가입하도록 유도
			mesg += "<h2>로그인실패</h2>";
			mesg +=" <a href='loginForm.html'>로그인화면</a>";
		}
		
		//응답처리
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print("<html><body>");
		out.print(mesg);
		out.print("</body></html>");
	}//end doGet

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");  // 나중에 Filter로 변경
		doGet(request, response);
	}

}
