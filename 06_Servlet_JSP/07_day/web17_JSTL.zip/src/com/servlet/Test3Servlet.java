package com.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.Person;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/Test3Servlet")
public class Test3Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		List<Person> list = Arrays.asList(new Person("홍길동1",20),
				new Person("홍길동2",30),
				new Person("홍길동3",40));
		
		request.setAttribute("list", list);
		
		
		request.setAttribute("tokens", "AAA/BBB/CCC");
		
		request.getRequestDispatcher("test3.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
