package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setAttribute("username", "홍길동");
		
		//fmt 실습
		request.setAttribute("price", 123456789);
		
		//fn 실습
		request.setAttribute("str", "HeLlo");
		request.setAttribute("str2", "980101-1234567");
		request.setAttribute("str3", "   홍길동     ");
		request.setAttribute("str4", "AAA/BBB/CCC");
		
		request.getRequestDispatcher("test.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
