package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.PageDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;

/**
 * Servlet implementation class BoardListServlet
 */
@WebServlet("/BoardListPageServlet")
public class BoardListPageServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		BoardService service = new BoardServiceImpl();
		
		String curPage = request.getParameter("curPage");
		
		// 맨처음 실행
		if(curPage == null) {
			curPage = "1";
		}
		
		//페이징 처리
		PageDTO pageDTO = service.selectAllPage(Integer.parseInt(curPage));
	
		//이전에는 여기서 응답처리했으나 이제는  list.jsp로 위임한다.
		request.setAttribute("pageDTO", pageDTO);
		
		request.getRequestDispatcher("listPage.jsp")
		       .forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
