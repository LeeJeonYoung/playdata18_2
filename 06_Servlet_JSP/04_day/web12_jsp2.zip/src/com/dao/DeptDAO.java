package com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.DeptDTO;

public class DeptDAO {
	//전체 레코드 조회
		public List<DeptDTO> selectAll(SqlSession session){
			List<DeptDTO> list= session.selectList("com.config.DeptMapper.selectAllDesc");
			return list;
		}
		
		//특정 레코드 조회 - deptno
		public DeptDTO selectByDeptno(SqlSession session, int deptno) {
			DeptDTO dto = session.selectOne("com.config.DeptMapper.selectByDeptno", deptno);
			return dto;
		}
		//저장
		public int insert(SqlSession session,DeptDTO dto) {
			int num = session.insert("com.config.DeptMapper.insert", dto);
			return num;
		}
		//특정 레코드 조회 - dname
		public List<DeptDTO> selectByDname(SqlSession session,String dname){
			return session.selectList("com.config.DeptMapper.selectByDname", dname);
		}
		//특정 레코드 조회 - dname과 loc
		public List<DeptDTO> selectByDnameLoc(SqlSession session,HashMap<String, String> map){
			return session.selectList("com.config.DeptMapper.selectByDnameLocMap", map);
		}
		//수정
		public int update(SqlSession session,DeptDTO dto) {
			int num = session.update("com.config.DeptMapper.update", dto);
			return num;
		}
		//삭제
		public int delete(SqlSession session,int deptno) {
			int num = session.delete("com.config.DeptMapper.delete", deptno);
			return num;
		}
}
