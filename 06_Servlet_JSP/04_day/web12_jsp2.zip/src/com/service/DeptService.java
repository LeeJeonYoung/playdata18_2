package com.service;

import java.util.HashMap;
import java.util.List;

import com.dto.DeptDTO;

public interface DeptService {

	//전체 레코드 조회
	public List<DeptDTO> selectAll();
	
	//특정 레코드 조회 - deptno
	public DeptDTO selectByDeptno(int deptno);
	
	//특정 레코드 조회 - dname
	public List<DeptDTO> selectByDname(String dname);
	
	//특정 레코드 조회 - dname과 loc
	public List<DeptDTO> selectByDnameLoc(HashMap<String, String> map);
	
	//저장
	public int insert(DeptDTO dto);
	
	//수정
	public int update(DeptDTO dto);
	
	//삭제
	public int delete(int deptno);
}
