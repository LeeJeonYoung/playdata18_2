package com.servlet;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetCookie
 */
@WebServlet("/SetCookie")
public class SetCookie extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//현재 시간 구하기
		Calendar cal = Calendar.getInstance();
		String time = cal.get(Calendar.YEAR)+"년" 
		+ cal.get(Calendar.HOUR_OF_DAY)+"시"+cal.get(Calendar.MINUTE)+"분"+cal.get(Calendar.SECOND);
		//1. 쿠키 생성
		Cookie c = new Cookie("current_time", time );
		
		// 시간설정
		c.setMaxAge(60*60);
		
		//2. 쿠키에 저장
		response.addCookie(c);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
