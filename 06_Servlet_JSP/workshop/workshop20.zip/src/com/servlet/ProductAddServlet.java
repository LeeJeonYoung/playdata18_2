package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Product;

/**
 * Servlet implementation class ProductAddServlet
 */
@WebServlet("/ProductAddServlet")
public class ProductAddServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("name");
		String id = request.getParameter("id");
		int amount = Integer.parseInt(request.getParameter("amount"));
        // 유일한 값을 얻기
		System.out.println(UUID.randomUUID().toString());
		System.out.println(System.currentTimeMillis());
		
		// 세션얻기
		HttpSession session = request.getSession();
		Product p = (Product) session.getAttribute(id);

		if (p == null) {
			// 고려하지 않은것은 time-out 이다. session.isNew()등 조건 사용
			p = new Product(name, id, amount);
			session.setAttribute(id, p);
		} else {
			p.setAmount(p.getAmount() + amount);
		}

		// 응답처리
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		out.println("<html><body>");
		out.println("<h2>상품 등록 성공</h2>");
		out.println("<a href='productForm.html'>등록화면보기</a><br>");
		out.println("<a href='ProductListServlet'>상품목록보기</a><br>");
		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
