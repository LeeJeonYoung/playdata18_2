package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Product;

/**
 * Servlet implementation class ProductAddServlet
 */
@WebServlet("/ProductDeleteServlet")
public class ProductDeleteServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id").trim().toLowerCase();
		// 고려하지 않은것은 time-out와 직접 요청 이다.
System.out.println("id"+ id +"\t" + id.length()+"\t"+id.trim().length());
		// 세션 얻기
		HttpSession session = request.getSession();
		Product p = (Product) session.getAttribute(id);
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		
		if (p != null && id.equalsIgnoreCase(p.getId().toLowerCase())) {
			session.removeAttribute(id);
			out.println("<h2>"+id+" 상품 삭제 성공</h2>");
			out.println("<a href='productForm.html'>등록화면보기</a><br>");
			out.println("<a href='ProductListServlet'>상품목록보기</a><br>");
		} else {
			// 상품이 없는 경우
			out.println("<h2>"+id+" 상품은 등록되지 않는 상품입니다.</h2>");
        	out.println("<a href='ProductListServlet'>상품목록보기</a><br>");
        	out.println("<a href='productDelete.html'>특정상품삭제</a><br>");
		}

		
		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
