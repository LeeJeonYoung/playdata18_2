package com.service;

import com.dto.MemberDTO;

public interface LoginService {

	public MemberDTO loginCheck(MemberDTO dto);
}
