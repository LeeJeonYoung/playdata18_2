package com.service;

import org.apache.ibatis.session.SqlSession;

import com.dao.LoginDAO;
import com.dto.MemberDTO;

public class LoginServiceImpl implements LoginService {

	@Override
	public MemberDTO loginCheck(MemberDTO dto) {
		
		MemberDTO result = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			LoginDAO dao = new LoginDAO();
			result = dao.loginCheck(session, dto);
		}finally {
			session.close();
		}
		return result;
	}

}
