package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.MemberDTO;
import com.service.LoginService;
import com.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		MemberDTO dto = new MemberDTO();
		dto.setUserid(userid);
		dto.setPasswd(passwd);
		
		LoginService service = new LoginServiceImpl();
		MemberDTO result = service.loginCheck(dto);
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		if(result == null) {
			//id 또는 pw 틀림 , 회원이 아님
			out.print("아이디와 비밀번호를 확인하세요.<br>");
			out.print("<a href='loginForm.html'>로그인 화면</a>");
		}else {
			//세션 얻기
			HttpSession session = request.getSession();
			session.setAttribute("login", result);
			
			out.print("환영합니다." + result.getUsername()+"<br>");
			out.print("<a href='LogoutServlet'>로그아웃</a><br>");
			out.print("<a href='MemberInfoServlet'>회원정보보기</a>");
		}
		
		
		out.print("</body>");
		out.print("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
