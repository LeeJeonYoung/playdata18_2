package com.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;
import com.dto.PageDTO;

public class BoardDAO {

	//목록보기
	public List<BoardDTO> selectAll(SqlSession session){
		return session.selectList("com.config.BoardMapper.selectAll");
	}
	
	//글저장
	public int insert(SqlSession session, BoardDTO dto) {
		return session.insert("com.config.BoardMapper.insert", dto);
	}
	
	//글자세히 보기
	public BoardDTO retrieveByNum(SqlSession session, int num) {
		//조회수증가 메서드 호출
		readcnt(session, num);
		session.commit();
		return session.selectOne("com.config.BoardMapper.retrieveByNum", num);
	}
	//조회수 수정
	private int readcnt(SqlSession session, int num) {
		return session.update("com.config.BoardMapper.readcnt", num);
	}
	
	//글수정
	public int update(SqlSession session, BoardDTO dto) {
		return session.update("com.config.BoardMapper.update", dto);
	}
	
	//글삭제
	public int delete(SqlSession session, int num) {
		return session.delete("com.config.BoardMapper.delete", num);
	}
	
	//페이징 처리
	public PageDTO selectAllPage(SqlSession session, int curPage) {
		
		PageDTO pageDTO = new PageDTO();
		int totalRecord = totalRecord(session); //전체 레코드 갯수
		int perPage=pageDTO.getPerPage(); //  페이지당 보여줄 레코드 갯수
		int offset = (curPage-1)*perPage; // select시 시작점
		List<BoardDTO> list = 
				session.selectList("com.config.BoardMapper.selectAllPage",
						           null,
						           new RowBounds(offset, perPage));
		
		//pageDTO 저장
		pageDTO.setList(list);
		pageDTO.setCurPage(curPage);
		pageDTO.setTotalRecord(totalRecord);
		
		return pageDTO;
		
	}
	//전체 레코드
	private int totalRecord(SqlSession session) {
		return session.selectOne("com.config.BoardMapper.totalRecord");
	}
	
	
}
