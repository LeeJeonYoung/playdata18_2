package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;

public class BoardDAO {

	//목록보기
	public List<BoardDTO> selectAll(SqlSession session){
		return session.selectList("com.config.BoardMapper.selectAll");
	}
	
	//글저장
	public int insert(SqlSession session, BoardDTO dto) {
		return session.insert("com.config.BoardMapper.insert", dto);
	}
	
	//글자세히 보기
	public BoardDTO retrieveByNum(SqlSession session, int num) {
		//조회수증가 메서드 호출
		readcnt(session, num);
		return session.selectOne("com.config.BoardMapper.retrieveByNum", num);
	}
	//조회수 수정
	private int readcnt(SqlSession session, int num) {
		return session.update("com.config.BoardMapper.readcnt", num);
	}
	
}
