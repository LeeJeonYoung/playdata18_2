package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;

public interface BoardService {
	public List<BoardDTO> selectAll();
	public int insert( BoardDTO dto);
	public BoardDTO retrieveByNum(int num);
	public int update( BoardDTO dto);
	public int delete( int num);
}
