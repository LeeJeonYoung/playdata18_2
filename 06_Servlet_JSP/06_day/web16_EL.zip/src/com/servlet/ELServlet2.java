package com.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Person;


@WebServlet("/ELServlet2")
public class ELServlet2 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//scope에 저장
		//2 session scope에 저장
		HttpSession session = request.getSession();
		
		session.setAttribute("session", "홍길동");
		
		Person p = new Person("이순신", 20);
		session.setAttribute("session2", p);
		
		List<Person> list =
				 Arrays.asList(new Person("유관순1", 18),
						 new Person("유관순2", 19));
		session.setAttribute("session3", list);
		
		
		//request.getRequestDispatcher("el2.jsp").forward(request, response);
		response.sendRedirect("el2.jsp");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
