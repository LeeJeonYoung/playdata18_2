package com.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.Person;


@WebServlet("/ELServlet")
public class ELServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//scope에 저장
		//1 request scope에 저장
		request.setAttribute("request", "홍길동");
		
		Person p = new Person("이순신", 20);
		request.setAttribute("request2", p);
		
		List<Person> list =
				 Arrays.asList(new Person("유관순1", 18),
						 new Person("유관순2", 19));
		request.setAttribute("request3", list);
		
		
		request.getRequestDispatcher("el.jsp").forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
