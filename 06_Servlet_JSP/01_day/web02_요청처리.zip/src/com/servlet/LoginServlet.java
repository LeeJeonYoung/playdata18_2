package com.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 *   서블릿은 단 한번만 생성된다. ===> 인스턴스변수가 한번만 생성된다.
 * 
 */
public class LoginServlet extends HttpServlet {
	
	//인스턴스 변수 ==> 여러 사용자가 공유 가능
	ArrayList<String> list = new ArrayList<String>();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("LoginServlet.doGet");
		
		list.add("Hello");
		
		System.out.println(list);
	}

}



