package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hello")
public class HelloServlet extends HttpServlet {

	// 생성할 때 호출되는 콜백 메서드(일반적으로 사용 안함)
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("HelloServlet.init");
	}
	
	// 삭제할 때 호출되는 콜백 메서드(일반적으로 사용 안함)
	@Override
	public void destroy() {
		System.out.println("HelloServlet.destroy");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

			//1) 비즈니스 로직처리
			System.out.println("HelloServlet.doGet");
		
		    //2) html 작성해서 응답
			
			Date d = new Date();
			
			//가. MIME 타입지정( 브라우저에게 처리할 데이터 타입 지정)
			// contentType 잘못지정하면 다운로드창이 나온다.
			response.setContentType("text/html;charset=utf-8");
			
			//나. 자바 I/O =>  출력 API
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			out.println("<h1>Hello</h1>");
			out.println("현재시간:"+d.toString());
			out.println("</body></html>");
	}
}




