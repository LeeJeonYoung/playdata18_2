package com.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// scope에 데이터 저장 역할
@WebServlet("/first")
public class FirstServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//1 application scope에 저장
		ServletContext application = getServletContext();
		application.setAttribute("application", "application");
		
		//2. session scope에 저장
		HttpSession session = request.getSession();
		session.setAttribute("session", "session");
		
		//3. request scope에 저장
		request.setAttribute("request", "request");
		
		System.out.println("scope 저장 성공");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
