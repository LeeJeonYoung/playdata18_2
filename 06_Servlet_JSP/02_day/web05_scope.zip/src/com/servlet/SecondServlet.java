package com.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//scope에 저장된 데이터 조회 역할
@WebServlet("/second")
public class SecondServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1 application scope에서 데이터 조회
		ServletContext application = getServletContext();
		String s = (String)application.getAttribute("application");
	
		//2 session scope에서 데이터 조회
		HttpSession session = request.getSession();
		String s2 = (String)session.getAttribute("session");
		
		//3 request scope에서 데이터 조회
		String s3 = (String)request.getAttribute("request");
		
		System.out.println("application:" + s);
		System.out.println("session:" + s2);
		System.out.println("request:" + s3);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
