package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.DeptDTO;

/*
 *   역할? ==> DB연동
 *   - SQL문작성
 *   - PreparedStatement 생성
 *   - int n = pstmt.executeUpdate()
 *     ResultSet rs = pstmt.executeQuery()
 *   - 결과데이터를 DeptMain에서 출력하도록
 *     결과데이터를 List<DeptDTO> 형식으로 
 *     만들어서 반환
 */
public class DeptDAO {

	// select
	public List<DeptDTO> selectAll(Connection con) {
		//누적용
		List<DeptDTO> list = new ArrayList<DeptDTO>(); 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select deptno as 부서번호, dname, loc from dept";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int deptno = rs.getInt("부서번호");
				String dname = rs.getString("dname");
				String loc = rs.getNString(3);
				DeptDTO dto = new DeptDTO(deptno, dname, loc);
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if (pstmt != null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}//end selectAll 메서드
	
	//부서번호로 검색
	public DeptDTO selectByDeptno(Connection con, int deptno) {
		DeptDTO dto = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select deptno as 부서번호, dname, loc from dept where deptno=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, deptno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String dname = rs.getString("dname");
				String loc = rs.getNString(3);
				dto = new DeptDTO(deptno, dname, loc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if (pstmt != null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}//end selectByDeptno
	
	//저장
	public int insert(Connection con, DeptDTO dto) {
		int num = 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into dept (deptno,dname,loc) values (?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dto.getDeptno());
			pstmt.setString(2, dto.getDname());
			pstmt.setString(3, dto.getLoc());
			num = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if (pstmt != null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num;
	}//end insert
	
	//삭제
	public int delete(Connection con, int deptno) {
		int num = 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "delet from dept where deptno = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, deptno);
			num = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if (pstmt != null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num;
	}//end delete

	//수정
	public int update(Connection con, DeptDTO dto) {
		int num = 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update dept set dname=?, loc=?  where deptno=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(3, dto.getDeptno());
			pstmt.setString(1, dto.getDname());
			pstmt.setString(2, dto.getLoc());
			num = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if (pstmt != null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num;
	}//end update
	//저장
		public int insert2(Connection con, DeptDTO dto) throws SQLException{
			int num = 0;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "insert into dept (deptno,dname,loc) values (?,?,?)";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, dto.getDeptno());
				pstmt.setString(2, dto.getDname());
				pstmt.setString(3, dto.getLoc());
				num = pstmt.executeUpdate();
			
			} finally {
				try {
					if(rs!=null)rs.close();
					if (pstmt != null)pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return num;
		}//end insert
		
		//삭제
		public int delete2(Connection con, int deptno) throws SQLException{
			int num = 0;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "delet from dept where deptno = ?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, deptno);
				num = pstmt.executeUpdate();
			
			} finally {
				try {
					if(rs!=null)rs.close();
					if (pstmt != null)pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return num;
		}//end delete
}//end class









