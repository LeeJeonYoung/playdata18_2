package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.DeptDTO;
import com.service.DeptService;
import com.service.DeptServiceImpl;

/**
 * Servlet implementation class DeptServlet
 */
@WebServlet("/DeptListServlet")
public class DeptListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//목록
		DeptService service = new DeptServiceImpl();
		List<DeptDTO> list = service.selectAll();
		for (DeptDTO deptDTO : list) {
			System.out.println(deptDTO);
		}
		//응답처리
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<table border='1'>");
		out.println("<tr><th>부서번호</th><th>부서명</th><th>부서위치</th></tr>");
		for (DeptDTO deptDTO : list) {
	      int deptno = deptDTO.getDeptno();
	      String dname = deptDTO.getDname();
	      String loc = deptDTO.getLoc();
		  out.println("<tr><th>"+deptno+"</th><th>"+dname+"</th><th>"+loc+"</th></tr>");
		}
		out.println("</table>");
		out.println("<a href='deptForm.html'>등록화면</a>");
		out.println("</body></html>");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
