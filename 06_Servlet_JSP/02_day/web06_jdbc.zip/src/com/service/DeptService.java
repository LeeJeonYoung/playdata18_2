package com.service;

import java.util.List;

import com.dto.DeptDTO;

/*   역할?
 *    -CRUD 할수 있는 추상 메서드 정의
 *    C-Create(저장인 insert 의미)
 *    R-Read(조회인 Select 의미)
 *    U-Update
 *    D-Delete
 */
public interface DeptService {

	//select
	public List<DeptDTO> selectAll();
	public DeptDTO selectByDeptno(int deptno);
	public int insert(DeptDTO dto);
	public int delete(int deptno);
	public int update(DeptDTO dto); 
	
	//트랜잭션 처리 실습 메서드
	public int tx();

}
