package com.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("TestServlet.doGet");
		//main.jsp로 위임
		//1)request scope 
		request.setAttribute("request", "request" );
		//2)session scope
		HttpSession session = request.getSession();
		session.setAttribute("session", "session" );
		//3) application scope
		ServletContext application = getServletContext();
		application.setAttribute("application", "application" );
	
		//1. 포워드 =>TestServlet에서 main.jsp로 url 변경 안됨.
		request.getRequestDispatcher("main.jsp").forward(request, response);
		
		//2. 리다이렉트==> TestServlet에서 main.jsp로 url 변경됨.
		//response.sendRedirect("main.jsp");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
