package com.service;

import java.util.List;


import com.dto.BoardDTO;

public interface BoardService {
	public List<BoardDTO> selectAll();
	public int insert( BoardDTO dto);
}
